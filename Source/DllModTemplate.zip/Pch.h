#pragma once

#include <Windows.h>
#include <detours.h>

#include <cstdint>
#include <cstdio>

#include <INIReader.h>
#include <Helpers.h>